# Changelog

Histórico de versões das skills e dos arquivos da marca.

Formato: [Semantic Versioning](https://semver.org/lang/pt-BR/) — MAJOR.MINOR.PATCH

---

## [Não publicado]

### A fazer
- Integrar a skill `email-marketing` ao formato deste hub (atualmente vive separado)
- Criar tutorial em vídeo de instalação para o time
- Adicionar skill de WhatsApp e copy de anúncios

---

## skills/instagram-content — 1.2.0 — 2026-05-04

### Adicionado
- **Integração com a planilha de Parceiros via Google Drive** (seção 7.0 da SKILL.md). Sempre que o conteúdo for collab, a skill instrui o Claude a ler a planilha oficial em tempo real e cruzar o nome do parceiro com a base, trazendo para o briefing o benefício ativo, o link e/ou cupom.
- Lógica de 3 cenários após leitura da planilha (parceiro com benefício / parceiro sem benefício / parceiro não cadastrado)
- Comportamento de fallback quando a planilha não pode ser lida (sem acesso, quota, erro de rede)
- 2 novos itens no checklist 7.5 (consulta à planilha + uso do cupom exato)
- Description da skill atualizada para mencionar a leitura em tempo real

### Modificado
- Pergunta 2 do briefing reescrita: agora aciona a leitura da planilha antes das demais perguntas de collab
- Seção 7 reorganizada: seção 7.0 (consulta), 7.1 (decisão), 7.2 (dados), 7.3 (copy), 7.4 (disclosure), 7.5 (checklist)

### Requer
- Pessoas do time que usam a skill precisam ter Google Drive conectado no Claude (instrução adicionada em USO_RECOMENDADO.md)

---

## brand/ — 1.0.0 — 2026-05-04

### Adicionado
- `brand/tom-de-voz.md` v2.0 — extraído do documento original `tom_de_voz_enp_v3.md`, ajustado para markdown sem travessão (que era padrão de IA banido)
- `brand/icp-produtos.md` v1.0 — perfis de ICP completos + detalhamento dos 3 produtos (Assinatura, Implementação, Consultoria)
- `brand/glossario.md` v1.0 — referência rápida de vocabulário usamos/evitamos/proibidas

---

## skills/instagram-content — 1.1.0 — 2026-05-04

### Adicionado
- Versão autocontida da skill: agora traz `tom-de-voz.md` e `icp-produtos.md` dentro de `references/` para funcionar igual em qualquer Claude
- Nota de autocontida no topo da SKILL.md

### Modificado
- Removida referência a "knowledge base do projeto", agora aponta para arquivos locais da skill
- Empacotamento agora inclui 4 arquivos (SKILL + 3 references)

## skills/instagram-content — 1.0.0 — 2026-05-04

### Adicionado
- Skill inicial de criação de conteúdo para Instagram do Ecommerce na Prática
- Cobertura dos 5 formatos: Stories, Feed estático, Carrossel, Reels, Roteiro de Live
- Briefing obrigatório com 6 perguntas (formato, parceria, objetivo, produto, ICP, CTA)
- Calibração por ICP (5, 2, 1, 4) com hooks aprovados
- Especificações de design e dimensão por formato
- Regras específicas para colaborações com parceiros (crédito, tom adaptado, CTA cruzado, disclosure)
- Aplicação de Cialdini, Godin e Ogilvy adaptada ao Instagram
- Padrão "Fazendo sozinho vs. Com nossa ajuda" como estrutura de conversão

---

## skills/email-marketing — pendente integração ao hub

A skill já existe em uso pelo time, mas vive fora deste repo. Integração planejada para o próximo ciclo. Versão atual: v1.1 (com briefing obrigatório, técnicas de copywriting, cadências por fluxo).

---

*Para reportar mudanças não documentadas ou solicitar uma nova versão, abrir uma issue.*
